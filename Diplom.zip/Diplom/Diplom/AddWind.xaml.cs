﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Diplom
{
    /// <summary>
    /// Логика взаимодействия для AddWind.xaml
    /// </summary>
    public partial class AddWind : Window
    {
        public static DB.DiplomEntities Connection= Class.Connector.GetDatabase();

        public DB.Product NewProduct { get; set; }
        public List<DB.Providers> providers { get; set; }
        public List<DB.Unit> units { get; set; }
        public AddWind()
        {
            InitializeComponent();
            NewProduct= new DB.Product();
            providers = new List<DB.Providers>(Connection.Providers.ToList());
            ProviderCombo.SetBinding(ComboBox.ItemsSourceProperty, new Binding() { Source = providers });
            units = new List<DB.Unit>(Connection.Unit.ToList());
            UnitCombo.SetBinding(ComboBox.ItemsSourceProperty, new Binding() { Source = units });
            DataContext = this;

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ProductPage.Connector.Product.Add(NewProduct);
            if (ProductPage.Connector.SaveChanges() == 1)
            {
                ProductPage.products.Add(NewProduct);
                NewProduct=new DB.Product();
                AddGrid.GetBindingExpression(DataContextProperty).UpdateTarget();
                this.Close();
            }
        }
    }
}
